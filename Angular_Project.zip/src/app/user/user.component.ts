import { TokenService } from './../_Service/token.service';
import { User } from './../_Model/User.model';
import { AuthenticationService } from './../_Service/authentication.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  providers: [AuthenticationService]
})
export class UserComponent implements OnInit {

  constructor(private auth: AuthenticationService, private token: TokenService) { }

  Users: User[] = [];
  flage_loding: boolean = false;
  ngOnInit() {
    if (this.token.flage_Login) {
      this.flage_loding = true;
      this.GetUsers()
    }

  }

  GetUsers() {
    this.auth.getUser()
      .subscribe(data => {
        console.log(data)
        this.Users = data;
      })
  }

  remove(j: any) {

  }

}
