import { Chart } from './../_Model/Chart.model';
import { TokenService } from './../_Service/token.service';
import { ChartService } from './../_Service/chart.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit {

  constructor(private chart: ChartService, private token: TokenService) { }

  Charts: Chart[] = [];
  temp_Chart: any[] = [];
  temp_index_Chart: any;
  flage_loding: boolean = false;

  ngOnInit() {
    if (this.token.flage_Login) {
      this.flage_loding = true;
      this.GetCharts();

    }
  }

  GetCharts() {
    this.chart.getCharts()
      .subscribe(data => {
        this.Charts = data;
        this.temp_Chart = [];
        this.full_Q();
      })
  }

  remove(j: any) {

  }

  send_index(index_Category: any) {
    this.temp_index_Chart = index_Category;
  }
  temp: number = 0;
  chart_Add: Chart[] = [];
  Add_Category(Category: any) {
    for (let index = 0; index < this.Charts.length; index++) {
      if (this.Charts[index].category == this.temp_Chart[this.temp_index_Chart]) {
        if (Category == this.Charts[index].subcategory) {
          this.temp = 1;
          break
        }
      }
    }

    if (this.temp == 0 && Category != this.temp_Chart[this.temp_index_Chart]) {
      //push chart
      this.chart_Add.push({ 'category': this.temp_Chart[this.temp_index_Chart], 'subcategory': Category })
      this.chart.addChart(this.chart_Add[0]).subscribe(data => {
        this.chart_Add = [];
        this.GetCharts();
      })
    }
    this.temp = 0;
  }

  // All Q {}
  full_Q() {
    for (var i = 0; i < this.Charts.length; i++) {
      if (this.temp_Chart.indexOf(this.Charts[i].category) === -1) {
        this.temp_Chart.push(this.Charts[i].category);
      }
      if (this.temp_Chart.indexOf(this.Charts[i].subcategory) === -1) {
        this.temp_Chart.push(this.Charts[i].subcategory);
      }
    }
    console.log( this.temp_Chart)
  }


}
