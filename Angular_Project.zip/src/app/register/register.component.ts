import { User } from './../_Model/User.model';
import { AuthenticationService } from './../_Service/authentication.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [AuthenticationService]
})
export class RegisterComponent implements OnInit {

  Users: User[] = [];
  user: User[] = [];

  form: any = {
    username: null,
    email: null,
    password: null
  };

  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';

  constructor(private auth: AuthenticationService) { }

  ngOnInit() {
    //this.refreshPeople()
  }

  refreshPeople() {
    this.isSuccessful=true;
    // this.auth.getUser()
    //   .subscribe(data => {
    //     console.log(data)
    //     this.Users = data;
    //   })

  }

  addUser() {
    const { username, email, password } = this.form;

    this.user.push({'user':username,'email':email,'password':password})
    this.auth.addUser(this.user[0])
      .subscribe(data => {
        this.refreshPeople();
      })
  }

  // onSubmit(): void {
  //   const { username, email, password } = this.form;

  //   this.auth.register();
  // }


}
