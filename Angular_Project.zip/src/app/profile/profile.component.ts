import { User } from './../_Model/User.model';
import { TokenService } from './../_Service/token.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private token: TokenService) { }
  token_user: User[] = [];
  flage_loding: boolean = false;
  ngOnInit(): void {
    if(this.token.flage_Login){
      this.token_user = this.token.user;
      this.flage_loding=true;
    }
    
  }

}
