
import { Chart } from './../_Model/Chart.model';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChartService {

  baseURL: string = "http://localhost:3000/";

  constructor(private http: HttpClient) { }

  getCharts(): Observable<Chart[]> {
    console.log('getchart '+this.baseURL + 'chart')
    return this.http.get<Chart[]>(this.baseURL + 'chart')
  }
 
  addChart(chart1:Chart): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    const body1=JSON.stringify(chart1);
    return this.http.post(this.baseURL + 'chart', body1 ,{'headers':headers})
  }
  
}
