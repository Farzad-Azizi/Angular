import { User } from './../_Model/User.model';

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class TokenService {

  constructor() { }
  user: User[] = [];
  flage_Login: boolean = false;
  Set(user: User) {
    this.user=[];
    this.user.push(user);
    this.flage_Login = true;
  }

  Get() {
  //   if (this.flage_Login) {
  //     return this.user[0].user;
  //   } else {
  //     return "";
  //   }
   }
}
