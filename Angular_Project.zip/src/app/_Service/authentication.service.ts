import { TokenService } from './token.service';
import { User } from './../_Model/User.model';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class AuthenticationService {
  baseURL: string = "http://localhost:3000/";
  constructor(private http: HttpClient) { }

  getUser(): Observable<User[]> {
    return this.http.get<User[]>(this.baseURL + 'user')
  }
 
  addUser(user:User): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(user);
    return this.http.post(this.baseURL + 'user', body ,{'headers':headers})
  }

}
