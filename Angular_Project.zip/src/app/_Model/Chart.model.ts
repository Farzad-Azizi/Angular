export interface Chart {
    category : any;
    subcategory: any;
}