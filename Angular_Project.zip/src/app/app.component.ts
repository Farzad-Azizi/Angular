import { User } from './_Model/User.model';
import { TokenService } from './_Service/token.service';
import { Component, DoCheck } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [TokenService]
})
export class AppComponent implements DoCheck {
  title = 'Angular_Project';
  Flage_Login: boolean = false;
  username = "";

  constructor(private token: TokenService) {
    // if (this.token.Get()){
    //  this.Flage_Login=true; 
    // }
  }
  ngOnInit(): void {
    if (this.token.flage_Login) {
      this.Flage_Login = true;
      this.username=this.token.user[0].user;
    }
  }

  ngDoCheck(): void {
    if (this.token.flage_Login) {
      this.Flage_Login = true;
      this.username=this.token.user[0].user;
    }
  }
  logout() {
  }
}
