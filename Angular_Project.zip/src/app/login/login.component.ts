import { User } from './../_Model/User.model';
import { AuthenticationService } from './../_Service/authentication.service';
import { TokenService } from './../_Service/token.service';
import { Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [AuthenticationService]
})
export class LoginComponent implements OnInit {

  Users: User[] = [];
  form: any = {
    username: null,
    password: null
  };
  isLoggedIn = false;

  constructor(private token: TokenService, private auth: AuthenticationService) { }

  ngOnInit(): void {
  }

  onSubmit() {
    const { username, password } = this.form;

    this.auth.getUser()
      .subscribe(data => {
        console.log(data)
        this.Users = data;
        for (let index = 0; index < this.Users.length; index++) {
          if (this.Users[index].user == username && this.Users[index].password == password) {
            this.token.Set(this.Users[index]);
            this.isLoggedIn = true;
          }
        }
      })
  }


}
